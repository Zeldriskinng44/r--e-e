
<div align="center">

## Advanced Modern Bot 

</div>
All in One Discord bot with latest tech,

This is a official  Repo of CodeX bot ! 




## Features 
- Anti Nuke
- Moderation
- Fun
- Custom Roles
- Developer Commands
- Multi Guild
- Much More 
  


## Screenshots

![App Screenshot 1](https://cdn.discordapp.com/attachments/1050042222495674375/1084847630049362001/image.png)


## Installation

Use node v16+

```bash
  npm install
  node index.js
```


## Important
Put Token in config.json

## Support 
[CodeX Development](https://dsc.gg/codexdev)

https://dsc.gg/codexdev